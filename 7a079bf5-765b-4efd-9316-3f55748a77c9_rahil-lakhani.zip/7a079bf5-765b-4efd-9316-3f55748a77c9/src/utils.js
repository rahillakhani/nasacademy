export const checkDate = (date) => {

    const dt = date.split("-")[0];
    const month = date.split("-")[1];
    const year = date.split("-")[2];
    if( dt < 1 || dt > 31){
        return false;
    }
    if(year > new Date().getFullYear()) {
        return false;
    }
    return true;
    // let date_regex = new RegExp(`\b(?:Jan(?:uary)?|Feb(?:ruary)?|...|Dec(?:ember)?)`);
    // console.log("month", month);
    // console.log("date_regex.test(month)",date_regex.test(month));
    // if (!(date_regex.test(month))) {
    //     return false;
    // }
};
