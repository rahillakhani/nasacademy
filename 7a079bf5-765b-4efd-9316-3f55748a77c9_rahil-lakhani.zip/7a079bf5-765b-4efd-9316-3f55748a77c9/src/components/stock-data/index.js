import React, {useEffect, useMemo, useState} from "react";
import {getData} from "../../api";
import {checkDate} from "../../utils";
import "./index.css";

export default function StockData() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState();
    const [date, setDate] = useState('5-January-2000');
    const [dataSet, setDataSet] = useState({});
    const inputChangeHandle = (event) => {
        setDate(event.target.value);
        if (checkDate(date)) {
            // TODO :: check month validitiy
            // check date to be less than 31
            // check year less than 2020
            setError("input invalid");
            return;
        } else {
            setError(null);

        }
    };

    const onSubmit = async () => {
        setError(null);
        setLoading(true);
        if (date.length < 10 || checkDate(date)) {
            // TODO :: check month validitiy
            // check date to be less than 31
            // check year less than 2020
            setError("input invalid");
            return;
        }
        const response = await getData(date);
        const error = response.status > 200;
        if (error) {
            setError("data failed");
            return;
        }
        const data = await response.json();
        const extractedData = data.data.filter(el => el.date === date);
        // setDataSet((prevData) => {
        //     return Object.assign(prevData, extractedData[0]);
        // });
        await setDataSet(extractedData[0]);
        setLoading(false);
    };

    return (
        <div className="layout-column align-items-center mt-50">
            {date}
            <section className="layout-row align-items-center justify-content-center">
                <input onChange={inputChangeHandle} type="text" className="large" placeholder="5-January-2000"
                       id="app-input" data-testid="app-input" value={date}/>
                <button onClick={onSubmit} className="" id="submit-button"
                        data-testid="submit-button">
                    Search
                </button>
            </section>
            {error && "error in input"}
            {loading && "loading..."}
            {dataSet?.date &&
                <ul className="mt-50 slide-up-fade-in styled" id="stockData" data-testid="stock-data">
                    <li className="py-10">Date:{dataSet.date}</li>
                    <li className="py-10">Open:{dataSet.open}</li>
                    <li className="py-10">Close: {dataSet.close}</li>
                    <li className="py-10">High: {dataSet.high}</li>
                    <li className="py-10">Low: {dataSet.low}</li>
                </ul>
            }
            <div className="mt-50 slide-up-fade-in" id="no-result" data-testid="no-result"></div>
        </div>
    );
}
