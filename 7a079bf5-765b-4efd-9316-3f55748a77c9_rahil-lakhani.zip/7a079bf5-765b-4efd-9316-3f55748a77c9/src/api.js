export const getData = (date) => {
    return fetch(`https://jsonmock.hackerrank.com/api/stocks?${date}`);
};
